<?php

$a = 2;
$b = 3;

$a++;

var_dump ($a >= $b);

