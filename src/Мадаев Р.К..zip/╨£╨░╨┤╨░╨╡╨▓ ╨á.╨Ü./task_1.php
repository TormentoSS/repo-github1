<?php

$a = 1234;
$b = 1.234;
$c = 5400;

$result = ($a + $b) <= $c;
var_dump($result);

