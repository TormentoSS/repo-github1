<?php

$a = 76;
$b = 8;

$result = $a % $b;

var_dump($result);

